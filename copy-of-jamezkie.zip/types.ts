// FIX: Defined and exported all necessary type interfaces. This file should only contain type definitions and not constants.
// This resolves import errors for Course, User, LearningPath, etc. across the entire application.
export interface Course {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  category: string;
  videos: number;
  classes: number;
  duration: string;
  rating: number;
}

export interface User {
  email: string;
  password: string;
  name: string;
  profileComplete: boolean;
  fullName?: string;
  mobile?: string;
  age?: number;
  role?: string;
  avatarUrl?: string;
  // FIX: Added optional status and enrollmentDetails properties to support the enrollment flow.
  status?: string;
  enrollmentDetails?: EnrollmentDetails;
}

// FIX: Added EnrollmentDetails interface to support the enrollment screen.
export interface EnrollmentDetails {
  fullName: string;
  gCashNumber: string;
  referenceNumber: string;
  paymentProof: string;
  gmail: string;
  submissionDate: string;
}

export interface Lesson {
  title: string;
  description: string;
}

export interface Module {
  title: string;
  description: string;
  lessons: Lesson[];
}

export interface LearningPath {
  modules: Module[];
}
