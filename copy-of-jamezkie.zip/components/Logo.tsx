import React from 'react';

const Logo: React.FC<{width?: number, height?: number}> = ({ width = 200, height = 200 }) => (
    <svg width={width} height={height} viewBox="0 0 150 150" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <radialGradient id="grad1" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                <stop offset="0%" style={{stopColor: 'rgb(255,255,0)', stopOpacity: 1}} />
                <stop offset="100%" style={{stopColor: 'rgb(0,191,255)', stopOpacity: 1}} />
            </radialGradient>
            <radialGradient id="grad2" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                <stop offset="0%" style={{stopColor: 'rgb(255,69,0)', stopOpacity: 1}} />
                <stop offset="100%" style={{stopColor: 'rgb(255,105,180)', stopOpacity: 1}} />
            </radialGradient>
             <linearGradient id="grad3" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style={{stopColor: 'rgb(50,205,50)', stopOpacity: 1}} />
                <stop offset="100%" style={{stopColor: 'rgb(255,255,0)', stopOpacity: 1}} />
            </linearGradient>
        </defs>
        <g transform="translate(75, 75)">
            <path d="M 0 -60 C 50 -60, 60 -30, 60 0 C 60 40, 30 60, 0 60 C -50 60, -60 30, -60 0 C -60 -50, -30 -60, 0 -60 Z" fill="url(#grad2)" transform="rotate(20)" />
            <path d="M 0 -55 C 45 -55, 55 -25, 55 0 C 55 35, 25 55, 0 55 C -45 55, -55 25, -55 0 C -55 -45, -25 -55, 0 -55 Z" fill="url(#grad1)" transform="rotate(-30)" />
            <path d="M 0 -50 C 40 -50, 50 -20, 50 0 C 50 30, 20 50, 0 50 C -40 50, -50 20, -50 0 C -50 -40, -20 -50, 0 -50 Z" fill="url(#grad3)" transform="rotate(10)" />
        
            <circle cx="0" cy="0" r="40" fill="#1e293b" />
            <text x="0" y="15" fontFamily="Arial, sans-serif" fontSize="48" fontWeight="bold" fill="white" textAnchor="middle" style={{filter: 'drop-shadow(0 0 5px white)'}}>
                J
            </text>
        </g>
    </svg>
);

export default Logo;
