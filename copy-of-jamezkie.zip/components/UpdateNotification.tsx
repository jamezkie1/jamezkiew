import React from 'react';
import { CHANGELOG } from '../updateInfo';
import { GiftIcon } from './icons/GiftIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';

interface UpdateNotificationProps {
  onClose: () => void;
}

const UpdateNotification: React.FC<UpdateNotificationProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[100] p-4 animate-fade-in">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full relative transform transition-all animate-fade-in-zoom">
        <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-orange-100 mb-4">
                <GiftIcon className="h-8 w-8 text-orange-500" />
            </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">What's New in Jamezkie</h2>
          <p className="text-gray-500 mb-6">We've been working hard on some exciting new features for you!</p>
        </div>

        <ul className="space-y-4 text-left">
          {CHANGELOG.map((item, index) => (
            <li key={index} className="flex items-start space-x-3">
                <div className="flex-shrink-0 mt-1">
                    <CheckCircleIcon className="w-5 h-5 text-green-500" />
                </div>
                <div>
                    <h4 className="font-semibold text-gray-800">{item.title}</h4>
                    <p className="text-gray-600 text-sm">{item.description}</p>
                </div>
            </li>
          ))}
        </ul>

        <div className="mt-8">
          <button
            onClick={onClose}
            className="w-full bg-orange-500 text-white font-bold py-3 rounded-lg hover:bg-orange-600 transition-colors transform hover:scale-105"
          >
            Continue to App
          </button>
        </div>
      </div>
    </div>
  );
};

export default UpdateNotification;
