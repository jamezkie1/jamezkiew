import React from 'react';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon';
import { ClockIcon } from './icons/ClockIcon';

interface PendingApprovalScreenProps {
  onBack: () => void;
}

const PendingApprovalScreen: React.FC<PendingApprovalScreenProps> = ({ onBack }) => {
  return (
    <div className="max-w-xl mx-auto p-4 font-sans animate-fade-in">
      <div className="flex items-center mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-blue-600 font-semibold transition-colors hover:text-blue-800 focus:outline-none"
        >
          <ArrowLeftIcon className="w-5 h-5" />
          Back to Courses
        </button>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-sm text-center">
        <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-blue-100 mb-4">
            <ClockIcon className="h-8 w-8 text-blue-500" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900">Enrollment Submitted</h1>
        <p className="text-gray-600 mt-2 max-w-sm mx-auto">
            Thank you! Your submission has been received and is now pending approval.
            This process usually takes 1-5 hours. You will be able to access all courses once your payment is confirmed.
        </p>
         <button
          onClick={onBack}
          className="mt-6 bg-orange-500 text-white font-bold py-2 px-6 rounded-full transition-all duration-300 transform hover:scale-105"
        >
          Go to Homepage
        </button>
      </div>
    </div>
  );
};

export default PendingApprovalScreen;
