import React, { useState, useRef } from 'react';
import { ChevronRightIcon } from './icons/ChevronRightIcon';

interface SwipeButtonProps {
    onSwipe: () => void;
}

const SWIPE_THRESHOLD = 0.75; // 75% of the track

const SwipeButton: React.FC<SwipeButtonProps> = ({ onSwipe }) => {
    const [swiping, setSwiping] = useState(false);
    const [swipeProgress, setSwipeProgress] = useState(0);
    const trackRef = useRef<HTMLDivElement>(null);
    const handleRef = useRef<HTMLDivElement>(null);

    const handlePointerDown = (e: React.PointerEvent) => {
        if (!trackRef.current || !handleRef.current) return;
        setSwiping(true);
        handleRef.current.setPointerCapture(e.pointerId);
    };
    
    const handlePointerMove = (e: React.PointerEvent) => {
        if (swiping && trackRef.current) {
            const trackRect = trackRef.current.getBoundingClientRect();
            const handleWidth = handleRef.current?.offsetWidth || 0;
            let newX = e.clientX - trackRect.left - (handleWidth / 2);
            
            // Clamp the position
            newX = Math.max(0, Math.min(newX, trackRect.width - handleWidth));

            const progress = newX / (trackRect.width - handleWidth);
            setSwipeProgress(progress);
        }
    };
    
    const handlePointerUp = (e: React.PointerEvent) => {
        if (swiping) {
            if (swipeProgress >= SWIPE_THRESHOLD) {
                setSwipeProgress(1);
                onSwipe();
            } else {
                setSwipeProgress(0); // Snap back
            }
            setSwiping(false);
            handleRef.current?.releasePointerCapture(e.pointerId);
        }
    };

    const handleStyle = {
        transform: `translateX(${swipeProgress * ((trackRef.current?.offsetWidth || 0) - (handleRef.current?.offsetWidth || 0))}px)`,
        transition: swiping ? 'none' : 'transform 0.2s ease-out',
    };

    const textStyle = {
        opacity: Math.max(0, 1 - swipeProgress * 2.5),
        transition: 'opacity 0.2s ease-out',
    };

    return (
        <div
            ref={trackRef}
            className="relative w-full h-16 bg-orange-500 rounded-full flex items-center justify-center p-2 user-select-none touch-none"
        >
            <span className="text-white font-semibold" style={textStyle}>
                Swipe to Go Home
            </span>
            <div
                ref={handleRef}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                className="absolute left-2 w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg cursor-grab active:cursor-grabbing"
                style={handleStyle}
            >
                <ChevronRightIcon className="w-6 h-6 text-orange-500" />
            </div>
        </div>
    );
};

export default SwipeButton;
