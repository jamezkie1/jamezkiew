import React from 'react';
import Logo from './Logo';

const SplashScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-gray-50 flex flex-col items-center justify-center z-[100] animate-fade-out" style={{ animationDelay: '2.5s' }}>
      <div className="animate-fade-in-zoom text-center">
        <Logo />
        <h1 className="text-4xl font-bold text-gray-900 mt-4">Jamezkie</h1>
        <p className="text-gray-600 mt-2">The All-in-One Course and Digital Products</p>
      </div>
    </div>
  );
};

export default SplashScreen;
