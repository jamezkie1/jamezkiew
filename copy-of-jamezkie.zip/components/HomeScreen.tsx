import React from 'react';
import Header from './Header';
import CourseList from './CourseList';
import { COURSES } from '../constants';
import { Course, User } from '../types';
import { SearchIcon } from './icons/SearchIcon';
import { FilterIcon } from './icons/FilterIcon';

interface HomeScreenProps {
    onSelectCourse: (course: Course) => void;
    currentUser: User | null;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ onSelectCourse, currentUser }) => {
    return (
        <div className="animate-fade-in">
            <Header currentUser={currentUser} />
            <main className="space-y-6">
                <div className="container mx-auto px-4 animate-fade-in-up" style={{ animationDelay: '100ms'}}>
                    <div className="flex items-center space-x-2">
                        <div className="relative flex-grow">
                            <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="text"
                                placeholder="Search now..."
                                className="w-full pl-12 pr-4 py-4 bg-white border border-gray-200 rounded-full text-gray-800 placeholder-gray-400 focus:ring-2 focus:ring-orange-400 focus:outline-none shadow-sm"
                            />
                        </div>
                        <button className="w-14 h-14 bg-orange-500 text-white rounded-full flex items-center justify-center flex-shrink-0 shadow-lg shadow-orange-500/30">
                            <FilterIcon className="w-6 h-6" />
                        </button>
                    </div>
                </div>

                <div className="container mx-auto px-4 animate-fade-in-up" style={{ animationDelay: '200ms'}}>
                    <div className="bg-orange-400 rounded-2xl p-6 text-white">
                        <p className="text-xl font-semibold mb-3">All courses are now free! Start your learning journey today.</p>
                        <div className="flex items-center space-x-3">
                            <button className="bg-orange-500 hover:bg-orange-600 transition-colors px-5 py-2.5 rounded-full font-semibold">Explore Courses</button>
                            <button className="bg-orange-500 hover:bg-orange-600 transition-colors px-5 py-2.5 rounded-full font-semibold">Start learning</button>
                        </div>
                    </div>
                </div>
                
                <CourseList courses={COURSES} onSelectCourse={onSelectCourse} currentUser={currentUser} />
            </main>
        </div>
    );
};

export default HomeScreen;
