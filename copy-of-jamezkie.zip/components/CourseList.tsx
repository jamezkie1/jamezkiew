

import React from 'react';
import { Course, User } from '../types';
import { HeartIcon } from './icons/HeartIcon';
import { VideoIcon } from './icons/VideoIcon';
import { UsersIcon } from './icons/UsersIcon';
import { ClockIcon } from './icons/ClockIcon';
import { StarIcon } from './icons/StarIcon';
import { LockIcon } from './icons/LockIcon';
import { getCourseProgressPercentage } from '../services/progressService';

interface CourseListProps {
  courses: Course[];
  onSelectCourse: (course: Course) => void;
  currentUser: User | null;
}

// FIX: Added currentUser to props to conditionally show progress.
const CourseCard: React.FC<{ course: Course; onSelect: () => void; progress: number; isLocked: boolean; currentUser: User | null; }> = ({ course, onSelect, progress, isLocked, currentUser }) => (
  <div
    role="button"
    tabIndex={0}
    onClick={onSelect}
    onKeyDown={(e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onSelect();
      }
    }}
    className="bg-white rounded-2xl shadow-sm overflow-hidden flex-shrink-0 w-64 cursor-pointer transform hover:-translate-y-1 transition-transform duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
  >
    <div className="relative h-40">
      <img className="w-full h-full object-cover" src={course.imageUrl} alt={course.title} />
      <div className={`absolute inset-0 bg-gradient-to-t from-purple-800/50 to-transparent ${isLocked ? 'backdrop-blur-sm' : ''}`}></div>
      {isLocked && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30">
            <LockIcon className="w-10 h-10 text-white/80" />
        </div>
      )}
      <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-semibold text-gray-800">
        {course.category}
      </div>
      <button className="absolute top-3 right-3 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center">
        <HeartIcon className="w-4 h-4 text-gray-600" />
      </button>
      <div className="absolute bottom-3 left-3 flex items-center space-x-2 text-white text-xs">
          <div className="flex items-center bg-black/30 backdrop-blur-sm px-2 py-1 rounded-full">
            <VideoIcon className="w-3 h-3 mr-1"/>
            <span>{course.videos} Videos</span>
          </div>
          <div className="flex items-center bg-black/30 backdrop-blur-sm px-2 py-1 rounded-full">
            <UsersIcon className="w-3 h-3 mr-1"/>
            <span>{course.classes} Class</span>
          </div>
      </div>
    </div>
    <div className="p-4">
      <h3 className="font-bold text-gray-900 leading-tight h-10">{course.title}</h3>
      {currentUser && progress > 0 && (
        <div className="mt-2">
            <div className="flex justify-between text-xs text-gray-500 mb-1">
                <span className="font-semibold">Progress</span>
                <span className="font-bold">{progress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div className="bg-green-500 h-1.5 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
        </div>
      )}
      <div className="flex justify-between items-center mt-3 text-sm">
        <div className="flex items-center bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
          <ClockIcon className="w-4 h-4 mr-1"/>
          <span>{course.duration}</span>
        </div>
        <div className="flex items-center text-gray-700">
          <StarIcon className="w-5 h-5 text-yellow-400 mr-1"/>
          <span className="font-bold">{course.rating}</span>
        </div>
      </div>
    </div>
  </div>
);

const CourseList: React.FC<CourseListProps> = ({ courses, onSelectCourse, currentUser }) => {
  const isLocked = !currentUser;
  
  return (
    <div className="space-y-4">
      <div className="px-4 container mx-auto flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Featured courses</h2>
            <p className="text-sm text-gray-500">Boost your global skills and career.</p>
          </div>
          <a href="#" className="text-sm font-semibold text-blue-600">See All</a>
      </div>

      <div className="flex space-x-4 overflow-x-auto p-4 -m-4">
        {courses.map((course, index) => {
          const progress = getCourseProgressPercentage(course.id);
          return (
            <div key={course.id} className="animate-fade-in-up" style={{ animationDelay: `${index * 150}ms`}}>
              <CourseCard 
                course={course} 
                progress={progress}
                isLocked={isLocked}
                onSelect={() => onSelectCourse(course)}
                currentUser={currentUser}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CourseList;
