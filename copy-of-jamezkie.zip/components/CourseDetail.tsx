import React, { useState, useEffect } from 'react';
import { Course, LearningPath } from '../types';
import { generateLearningPath } from '../services/geminiService';
import { getStoredCourseData, storeLearningPath, toggleLessonComplete } from '../services/progressService';
import LearningPathComponent from './LearningPath';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon';
import AuraLoader from './AuraLoader';

interface CourseDetailProps {
  course: Course;
  onBack: () => void;
}

const CourseDetail: React.FC<CourseDetailProps> = ({ course, onBack }) => {
  const [learningPath, setLearningPath] = useState<LearningPath | null>(null);
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const storedData = getStoredCourseData(course.id);
    if (storedData) {
      setLearningPath(storedData.learningPath);
      setCompletedLessons(new Set(storedData.completedLessons));
    }
  }, [course.id]);

  const handleGeneratePath = async () => {
    setIsLoading(true);
    setError(null);
    if (!learningPath) { // Only clear if we are generating for the first time
      setLearningPath(null);
    }
    try {
      const path = await generateLearningPath(course.title);
      setLearningPath(path);
      storeLearningPath(course.id, path);
    } catch (err: any) {
      setError(err.message || 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleLessonComplete = (lessonTitle: string) => {
    toggleLessonComplete(course.id, lessonTitle);
    
    const newCompleted = new Set(completedLessons);
    if (newCompleted.has(lessonTitle)) {
      newCompleted.delete(lessonTitle);
    } else {
      newCompleted.add(lessonTitle);
    }
    setCompletedLessons(newCompleted);
  };

  const totalLessons = learningPath ? learningPath.modules.reduce((acc, mod) => acc + mod.lessons.length, 0) : 0;
  const progressPercentage = totalLessons > 0 ? Math.round((completedLessons.size / totalLessons) * 100) : 0;

  return (
    <div className="max-w-xl mx-auto p-4 font-sans">
       <div className="flex items-center mb-4">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-blue-600 font-semibold transition-colors hover:text-blue-800 focus:outline-none"
        >
          <ArrowLeftIcon className="w-5 h-5" />
          Back to Courses
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm overflow-hidden mb-6 animate-fade-in-zoom">
        <img className="w-full h-48 object-cover" src={course.imageUrl} alt={course.title} />
      </div>

      <div className="px-2 space-y-2 animate-fade-in-up" style={{ animationDelay: '200ms' }}>
        <p className="uppercase tracking-wide text-sm text-blue-500 font-semibold">{course.category}</p>
        <h1 className="block text-3xl leading-tight font-bold text-gray-900">{course.title}</h1>
        <p className="text-gray-600">{course.description}</p>
      </div>

      {learningPath && totalLessons > 0 && (
        <div className="my-6 px-2 animate-fade-in-up" style={{ animationDelay: '300ms' }}>
          <div className="flex justify-between items-center mb-1">
            <h3 className="text-lg font-bold text-gray-800">Course Progress</h3>
            <span className="font-bold text-green-600">{progressPercentage}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className="bg-green-500 h-2.5 rounded-full transition-all duration-500" style={{ width: `${progressPercentage}%` }}></div>
          </div>
        </div>
      )}
      
      <div className="mt-8">
        {isLoading ? (
          <AuraLoader />
        ) : error ? (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative text-center" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
             <button
                onClick={handleGeneratePath}
                className="mt-4 bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-6 rounded-full transition-all duration-300 transform hover:scale-105"
            >
                Retry
            </button>
          </div>
        ) : !learningPath ? (
           <div className="text-center animate-fade-in-up" style={{ animationDelay: '400ms' }}>
            <button
                onClick={handleGeneratePath}
                className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg animate-pulse-glow"
            >
                Generate AI Learning Path
            </button>
          </div>
        ) : null}
      </div>

      {learningPath && <LearningPathComponent path={learningPath} completedLessons={completedLessons} onToggleLesson={handleToggleLessonComplete} />}
    </div>
  );
};

export default CourseDetail;