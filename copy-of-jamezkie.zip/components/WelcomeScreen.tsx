import React, { useEffect } from 'react';
import Logo from './Logo';

interface WelcomeScreenProps {
  onFinished: () => void;
  userName: string;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onFinished, userName }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinished();
    }, 2000); // 2 seconds

    return () => clearTimeout(timer);
  }, [onFinished]);

  return (
    <div className="fixed inset-0 bg-gray-50 flex flex-col items-center justify-center z-[90] animate-fade-in">
      <div className="absolute top-8">
         <Logo width={80} height={80} />
      </div>
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-800 animate-typing overflow-hidden whitespace-nowrap border-r-4 border-r-gray-800">
            Welcome to Jamezkie
        </h2>
      </div>
      <div className="absolute bottom-16">
        <div className="w-8 h-8 border-4 border-orange-400 border-t-transparent rounded-full animate-spin"></div>
      </div>
    </div>
  );
};

export default WelcomeScreen;
