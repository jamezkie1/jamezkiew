import React from 'react';

const SkeletonModule: React.FC = () => (
  <div className="border border-gray-200 rounded-lg p-5 bg-white/50">
    <div className="flex justify-between items-center">
      <div className="space-y-3 flex-1 pr-4">
        <div className="h-6 bg-gray-200 rounded w-3/4"></div>
        <div className="h-4 bg-gray-200 rounded w-full"></div>
      </div>
      <div className="w-6 h-6 bg-gray-200 rounded-md"></div>
    </div>
  </div>
);

const LearningPathSkeleton: React.FC = () => {
  return (
    <div className="mt-8 animate-pulse" aria-label="Loading learning path">
      <div className="h-8 bg-gray-200 rounded w-1/2 mx-auto mb-6"></div>
      <div className="space-y-4">
        <SkeletonModule />
        <SkeletonModule />
        <SkeletonModule />
      </div>
    </div>
  );
};

export default LearningPathSkeleton;
