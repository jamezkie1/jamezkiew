import React from 'react';
import { BookOpenIcon } from './icons/BookOpenIcon';

const AuraLoader: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8 space-y-6 my-8">
      <div className="relative w-32 h-32 flex items-center justify-center">
        {/* Aura effect rings */}
        <div className="absolute inset-0 bg-orange-400 rounded-full opacity-20 animate-ping"></div>
        <div style={{ animationDelay: '1s' }} className="absolute inset-0 bg-orange-400 rounded-full opacity-20 animate-ping"></div>
        
        {/* Central icon container */}
        <div className="relative w-24 h-24 bg-white rounded-full shadow-lg flex items-center justify-center">
          <BookOpenIcon className="w-12 h-12 text-orange-500" />
        </div>
      </div>
      <div className="relative">
        <p className="font-semibold text-lg text-gray-800">Course Generated</p>
        <p className="text-gray-500">(Please wait...)</p>
      </div>
    </div>
  );
};

export default AuraLoader;
