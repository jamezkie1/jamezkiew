import React, { useState } from 'react';
import { User } from '../types';
import SwipeButton from './SwipeButton';

interface SetupProfileScreenProps {
    onProfileComplete: (data: Partial<User>) => void;
}

const SetupProfileScreen: React.FC<SetupProfileScreenProps> = ({ onProfileComplete }) => {
    const [fullName, setFullName] = useState('');
    const [mobile, setMobile] = useState('');
    const [age, setAge] = useState('');
    const [role, setRole] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = () => {
        if (!fullName || !mobile || !age || !role) {
            setError('Please fill out all fields to continue.');
            return;
        }
        setError('');
        onProfileComplete({
            fullName,
            mobile,
            age: parseInt(age, 10),
            role,
        });
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">Complete Your Profile</h1>
                    <p className="text-gray-500 mt-2">Let's get you set up for a personalized experience.</p>
                </div>

                <div className="bg-white p-8 rounded-2xl shadow-md space-y-4">
                    {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                    <div>
                        <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">Full Name</label>
                        <input type="text" id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-orange-500 focus:border-orange-500" placeholder="Alex Morgan"/>
                    </div>
                     <div>
                        <label htmlFor="mobile" className="block text-sm font-medium text-gray-700">Mobile Number</label>
                        <input type="tel" id="mobile" value={mobile} onChange={(e) => setMobile(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-orange-500 focus:border-orange-500" placeholder="+1 (555) 123-4567"/>
                    </div>
                     <div>
                        <label htmlFor="age" className="block text-sm font-medium text-gray-700">Age</label>
                        <input type="number" id="age" value={age} onChange={(e) => setAge(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-orange-500 focus:border-orange-500" placeholder="25"/>
                    </div>
                    <div>
                        <label htmlFor="role" className="block text-sm font-medium text-gray-700">You are a...</label>
                        <select id="role" value={role} onChange={(e) => setRole(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-orange-500 focus:border-orange-500 sm:text-sm rounded-md">
                            <option value="">Select a role</option>
                            <option value="student">Student</option>
                            <option value="freelancer">Freelancer</option>
                            <option value="professional">Working Professional</option>
                             <option value="other">Other</option>
                        </select>
                    </div>
                </div>

                <div className="mt-8">
                    <SwipeButton onSwipe={handleSubmit} />
                </div>
            </div>
        </div>
    );
};

export default SetupProfileScreen;
