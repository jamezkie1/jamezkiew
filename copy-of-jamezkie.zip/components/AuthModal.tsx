import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { GoogleIcon } from './icons/GoogleIcon';
import { GithubIcon } from './icons/GithubIcon';
import { FacebookIcon } from './icons/FacebookIcon';
import { XIcon } from './icons/XIcon';

interface AuthModalProps {
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  onSignupSuccess: (user: User) => void;
  onAdminLogin: () => void;
}

type AuthMode = 'login' | 'signup' | 'forgot_email' | 'forgot_otp' | 'forgot_reset' | 'admin';

const AuthModal: React.FC<AuthModalProps> = ({ onClose, onLoginSuccess, onSignupSuccess, onAdminLogin }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [adminUsername, setAdminUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminVerification, setAdminVerification] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const clearForm = () => {
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setOtp('');
    setAdminUsername('');
    setAdminPassword('');
    setAdminVerification('');
    setError('');
    setSuccess('');
  };

  const switchMode = (newMode: AuthMode) => {
    setMode(newMode);
    clearForm();
  };
  
  const handleSocialLogin = (provider: 'Google' | 'Github' | 'Facebook') => {
    const socialEmail = `${provider.toLowerCase()}_user@example.com`;
    const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
    let user = users.find(u => u.email === socialEmail);

    if (!user) {
        user = {
            email: socialEmail,
            password: Math.random().toString(36).slice(-8), // Dummy password
            name: `${provider} User`,
            profileComplete: false,
        };
        users.push(user);
        localStorage.setItem('users', JSON.stringify(users));
    }
    onLoginSuccess(user);
  };
  
  const handleAdminSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (adminUsername === 'james' && adminPassword === 'hondsome ko' && adminVerification === 'jamezkie') {
          onAdminLogin();
      } else {
          setError('Invalid admin credentials.');
      }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');

    if (mode === 'signup') {
      if (password !== confirmPassword) {
        return setError("Passwords do not match.");
      }
      if (users.some(user => user.email === email)) {
        return setError("An account with this email already exists.");
      }
      const newUser: User = { 
        email, 
        password, 
        name: email.split('@')[0],
        profileComplete: false,
      };
      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      onSignupSuccess(newUser);
    }
    
    if (mode === 'login') {
      const user = users.find(u => u.email === email);
      if (!user) {
        return setError("No account found with this email.");
      }
      if (user.password !== password) {
        return setError("Incorrect password.");
      }
      onLoginSuccess(user);
    }
    
    if (mode === 'forgot_email') {
        const user = users.find(u => u.email === email);
        if (!user) {
            return setError("No account found with this email.");
        }
        const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
        sessionStorage.setItem('otp', generatedOtp);
        sessionStorage.setItem('otp_email', email);
        console.log(`Password reset OTP for ${email}: ${generatedOtp}`);
        setSuccess(`An OTP has been sent to your email (check the console).`);
        setTimeout(() => switchMode('forgot_otp'), 1000);
    }
    
    if (mode === 'forgot_otp') {
        const storedOtp = sessionStorage.getItem('otp');
        if (otp !== storedOtp) {
            return setError("Invalid OTP. Please try again.");
        }
        sessionStorage.removeItem('otp');
        switchMode('forgot_reset');
    }
    
    if (mode === 'forgot_reset') {
        if (password !== confirmPassword) {
            return setError("Passwords do not match.");
        }
        const resetEmail = sessionStorage.getItem('otp_email');
        const userIndex = users.findIndex(u => u.email === resetEmail);
        if (userIndex === -1) {
            return setError("An unexpected error occurred. Please restart the process.");
        }
        users[userIndex].password = password;
        localStorage.setItem('users', JSON.stringify(users));
        sessionStorage.removeItem('otp_email');
        setSuccess('Password reset successfully! You can now log in.');
        setTimeout(() => switchMode('login'), 2000);
    }
  };

  const renderFormContent = () => {
    switch (mode) {
      case 'admin':
        return (
             <>
                <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">Admin Login</h2>
                <p className="text-center text-gray-500 mb-6">Enter your administrator credentials.</p>
                <form onSubmit={handleAdminSubmit} className="space-y-4">
                    <input type="text" placeholder="Username" value={adminUsername} onChange={e => setAdminUsername(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                    <input type="password" placeholder="Password" value={adminPassword} onChange={e => setAdminPassword(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                    <input type="text" placeholder="Verification Code" value={adminVerification} onChange={e => setAdminVerification(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                    <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition-colors">
                        Access Panel
                    </button>
                    <button type="button" onClick={() => switchMode('login')} className="w-full text-center text-sm text-blue-600 hover:underline">Back to User Login</button>
                </form>
            </>
        );
      case 'forgot_email':
      case 'forgot_otp':
      case 'forgot_reset':
        return (
            <>
                <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">Reset Password</h2>
                <p className="text-center text-gray-500 mb-6">
                    {mode === 'forgot_email' && "Enter your email to receive a reset code."}
                    {mode === 'forgot_otp' && "Enter the 6-digit code sent to your email."}
                    {mode === 'forgot_reset' && "Enter your new password."}
                </p>
                <form onSubmit={handleSubmit} className="space-y-4">
                    {mode === 'forgot_email' && (
                        <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                    )}
                    {mode === 'forgot_otp' && (
                        <input type="text" placeholder="6-Digit OTP" value={otp} onChange={e => setOtp(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                    )}
                    {mode === 'forgot_reset' && (
                        <>
                            <input type="password" placeholder="New Password" value={password} onChange={e => setPassword(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                            <input type="password" placeholder="Confirm New Password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                        </>
                    )}
                    <button type="submit" className="w-full bg-orange-500 text-white font-bold py-3 rounded-lg hover:bg-orange-600 transition-colors">
                        {mode === 'forgot_email' && "Send OTP"}
                        {mode === 'forgot_otp' && "Verify OTP"}
                        {mode === 'forgot_reset' && "Reset Password"}
                    </button>
                    <button type="button" onClick={() => switchMode('login')} className="w-full text-center text-sm text-blue-600 hover:underline">Back to Login</button>
                </form>
            </>
        );
      case 'login':
      case 'signup':
      default:
        return (
            <>
                <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">{mode === 'login' ? 'Welcome Back!' : 'Create Account'}</h2>
                <p className="text-center text-gray-500 mb-6">{mode === 'login' ? 'Sign in to continue your journey.' : 'Join us to start learning.'}</p>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                    <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                    <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                    {mode === 'signup' && (
                         <input type="password" placeholder="Confirm Password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className="w-full px-4 py-3 border border-gray-300 rounded-lg" />
                    )}
                    {mode === 'login' && (
                        <div className="text-right">
                            <button type="button" onClick={() => switchMode('forgot_email')} className="text-sm text-blue-600 hover:underline">Forgot Password?</button>
                        </div>
                    )}
                    <button type="submit" className="w-full bg-orange-500 text-white font-bold py-3 rounded-lg hover:bg-orange-600 transition-colors">
                        {mode === 'login' ? 'Log In' : 'Sign Up'}
                    </button>
                </form>

                <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-gray-300"></span></div>
                    <div className="relative flex justify-center text-sm"><span className="bg-white px-2 text-gray-500">OR</span></div>
                </div>

                <div className="space-y-3">
                    <button onClick={() => handleSocialLogin('Google')} className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                        <GoogleIcon className="w-6 h-6" />
                        <span className="font-semibold text-gray-700">Continue with Google</span>
                    </button>
                    {/* Other social logins omitted for brevity but would follow the same pattern */}
                </div>
                 <p className="text-sm text-gray-500 text-center mt-6">
                    {mode === 'login' ? "Don't have an account?" : "Already have an account?"}
                    <button onClick={() => switchMode(mode === 'login' ? 'signup' : 'login')} className="font-semibold text-blue-600 hover:underline ml-1">
                        {mode === 'login' ? 'Sign Up' : 'Log In'}
                    </button>
                </p>
                <div className="text-center mt-4">
                     <button onClick={() => switchMode('admin')} className="text-xs text-gray-400 hover:text-gray-600 hover:underline">
                        Admin Login
                    </button>
                </div>
            </>
        );
    }
  };

  return (
    <div 
        onClick={handleOverlayClick}
        className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 animate-fade-in"
    >
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-sm w-full relative transform transition-all animate-in slide-in-from-bottom-10 duration-300">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <XIcon className="w-6 h-6" />
        </button>
        {error && <p className="bg-red-100 text-red-700 text-sm font-semibold p-3 rounded-lg mb-4 text-center">{error}</p>}
        {success && <p className="bg-green-100 text-green-700 text-sm font-semibold p-3 rounded-lg mb-4 text-center">{success}</p>}
        {renderFormContent()}
      </div>
    </div>
  );
};

export default AuthModal;
