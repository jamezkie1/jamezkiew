

import React, { useState, useRef } from 'react';
import { User } from '../types';
import { ChevronRightIcon } from './icons/ChevronRightIcon';
import { LockClosedIcon } from './icons/LockClosedIcon';
import { GraduationCapIcon } from './icons/GraduationCapIcon';
import { BellIcon } from './icons/BellIcon';
import { CameraIcon } from './icons/CameraIcon';

interface ProfileScreenProps {
  user: User;
  onLogout: () => void;
  onUpdateProfile: (data: Partial<User>) => void;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ user, onLogout, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    fullName: user.fullName || '',
    mobile: user.mobile || '',
    age: user.age || '',
    role: user.role || '',
    avatarUrl: user.avatarUrl || '',
  });

  const [passwordData, setPasswordData] = useState({
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
  });
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, avatarUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileSelect = () => fileInputRef.current?.click();

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveProfile = () => {
    onUpdateProfile({
      ...formData,
      age: Number(formData.age)
    });
    setIsEditing(false);
    setShowSaveSuccess(true);
    setTimeout(() => setShowSaveSuccess(false), 3000); // Hide message after 3 seconds
  };
  
  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (passwordData.newPassword !== passwordData.confirmPassword) {
        return setPasswordError('New passwords do not match.');
    }
    if (user.password !== passwordData.currentPassword) {
        return setPasswordError('Incorrect current password.');
    }
    
    onUpdateProfile({ password: passwordData.newPassword });
    setPasswordSuccess('Password updated successfully!');
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
    setTimeout(() => {
        setIsChangingPassword(false)
        setPasswordSuccess('')
    }, 2000);
  };

  const handleStartEditing = () => {
    setFormData({
      fullName: user.fullName || '',
      mobile: user.mobile || '',
      age: user.age ? String(user.age) : '',
      role: user.role || '',
      avatarUrl: user.avatarUrl || '',
    });
    setIsEditing(true);
  };

  const displayAvatar = isEditing ? formData.avatarUrl : user.avatarUrl;
  const avatarSrc = displayAvatar || `https://ui-avatars.com/api/?name=${user.fullName || user.name}&background=fdba74&color=fff&bold=true`;

  return (
    <div className="bg-gray-50 min-h-screen animate-fade-in">
       <header className="px-4 pt-8 pb-4">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-gray-900">My Profile</h1>
          <p className="text-gray-500">Manage your account settings and preferences.</p>
        </div>
      </header>

      <main className="container mx-auto px-4 pb-10">
        <div className="max-w-md mx-auto space-y-6">

            {showSaveSuccess && (
                <div className="bg-green-100 text-green-700 p-4 rounded-lg font-semibold text-center animate-fade-in">
                    Profile saved successfully!
                </div>
            )}
            
            <div className="bg-white p-6 rounded-2xl shadow-sm animate-fade-in-up" style={{ animationDelay: '100ms' }}>
                <div className="flex items-center space-x-4">
                     <div className="relative">
                        <img 
                            src={avatarSrc} 
                            alt={user.fullName || user.name} 
                            className="w-16 h-16 rounded-full object-cover"
                        />
                        {isEditing && (
                            <>
                                <input 
                                    type="file" 
                                    ref={fileInputRef} 
                                    onChange={handleImageChange}
                                    accept="image/*"
                                    className="hidden"
                                />
                                <button 
                                    onClick={triggerFileSelect}
                                    className="absolute bottom-0 right-0 w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center text-white hover:bg-orange-600 transition-colors shadow"
                                    aria-label="Upload profile picture"
                                >
                                    <CameraIcon className="w-4 h-4" />
                                </button>
                            </>
                        )}
                    </div>
                    <div className="flex-grow">
                        <h2 className="font-bold text-xl text-gray-800">{isEditing ? 'Edit Profile' : user.fullName || user.name}</h2>
                        <p className="text-gray-500 text-sm">{user.email}</p>
                    </div>
                    {!isEditing && (
                        <button onClick={handleStartEditing} className="bg-orange-100 text-orange-600 font-semibold px-4 py-2 rounded-lg text-sm transition hover:bg-orange-200 focus:outline-none focus:ring-2 focus:ring-orange-400">
                            Edit
                        </button>
                    )}
                </div>

                {isEditing ? (
                    <div className="mt-6 pt-6 border-t border-gray-100 space-y-4 animate-fade-in">
                        <EditInput label="Full Name" name="fullName" value={formData.fullName} onChange={handleInputChange} />
                        <EditInput label="Mobile Number" name="mobile" value={formData.mobile} onChange={handleInputChange} placeholder="+1 (555) 123-4567" />
                        <EditInput label="Age" name="age" type="number" value={formData.age} onChange={handleInputChange} placeholder="25" />
                        <EditSelect label="Role" name="role" value={formData.role} onChange={handleInputChange}>
                            <option value="">Select a role</option>
                            <option value="student">Student</option>
                            <option value="freelancer">Freelancer</option>
                            <option value="professional">Working Professional</option>
                            <option value="other">Other</option>
                        </EditSelect>
                        <div className="flex gap-3 pt-2">
                            <button onClick={handleSaveProfile} className="flex-1 bg-orange-500 text-white font-bold py-3 rounded-lg hover:bg-orange-600 transition-colors">Save Changes</button>
                            <button onClick={() => setIsEditing(false)} className="flex-1 bg-gray-200 text-gray-800 font-semibold py-3 rounded-lg hover:bg-gray-300 transition-colors">Cancel</button>
                        </div>
                    </div>
                ) : (
                    <div className="mt-6 border-t border-gray-100 pt-6 space-y-4">
                        <InfoRow label="Access" value="Lifetime Access" />
                        <InfoRow label="Full Name" value={user.fullName} />
                        <InfoRow label="Mobile" value={user.mobile} />
                        <InfoRow label="Age" value={user.age} />
                        <InfoRow label="Role" value={user.role} />
                    </div>
                )}
            </div>

            <div className="bg-white rounded-2xl shadow-sm overflow-hidden animate-fade-in-up" style={{ animationDelay: '200ms' }}>
                <ul className="divide-y divide-gray-100">
                    <li>
                        <button onClick={() => setIsChangingPassword(!isChangingPassword)} className="w-full flex items-center p-4 text-left text-gray-700 hover:bg-gray-50 transition-colors" aria-expanded={isChangingPassword}>
                            <div className="w-6 h-6 mr-4 text-gray-500"><LockClosedIcon /></div>
                            <span className="flex-grow font-semibold">Change Password</span>
                            <ChevronRightIcon className={`w-5 h-5 text-gray-400 transform transition-transform ${isChangingPassword ? 'rotate-90' : ''}`} />
                        </button>
                        {isChangingPassword && (
                            <form onSubmit={handleUpdatePassword} className="p-4 border-t bg-gray-50 space-y-3 animate-fade-in">
                                {passwordError && <p className="text-red-500 text-sm text-center font-semibold">{passwordError}</p>}
                                {passwordSuccess && <p className="text-green-500 text-sm text-center font-semibold">{passwordSuccess}</p>}
                                <input type="password" name="currentPassword" placeholder="Current Password" value={passwordData.currentPassword} onChange={handlePasswordChange} required className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500" />
                                <input type="password" name="newPassword" placeholder="New Password" value={passwordData.newPassword} onChange={handlePasswordChange} required className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500" />
                                <input type="password" name="confirmPassword" placeholder="Confirm New Password" value={passwordData.confirmPassword} onChange={handlePasswordChange} required className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500" />
                                <button type="submit" className="w-full bg-orange-500 text-white font-semibold py-2.5 rounded-lg text-sm hover:bg-orange-600 transition-colors">Update Password</button>
                            </form>
                        )}
                    </li>
                    <SettingsListItem icon={<GraduationCapIcon />} label="My Courses" onClick={() => alert('The "My Courses" page is for demonstration purposes and is not implemented yet.')} />
                    <SettingsListItem icon={<BellIcon />} label="Notifications" onClick={() => alert('Feature coming soon!')} />
                </ul>
            </div>
            
            <button onClick={onLogout} className="w-full bg-red-50 text-red-600 font-semibold py-3 rounded-lg hover:bg-red-100 transition-colors animate-fade-in-up" style={{ animationDelay: '300ms' }}>
                Log Out
            </button>
        </div>
      </main>
    </div>
  );
};

const SettingsListItem: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void; }> = ({ icon, label, onClick }) => (
    <li>
      <button onClick={onClick} className="w-full flex items-center p-4 text-left text-gray-700 hover:bg-gray-50 transition-colors">
        <div className="w-6 h-6 mr-4 text-gray-500">{icon}</div>
        <span className="flex-grow font-semibold">{label}</span>
        <ChevronRightIcon className="w-5 h-5 text-gray-400" />
      </button>
    </li>
);

const InfoRow: React.FC<{ label: string; value?: string | number | React.ReactNode | null }> = ({ label, value }) => (
  <div className="flex justify-between items-center text-sm">
    <span className="text-gray-500">{label}</span>
    <span className="font-semibold text-gray-800">{typeof value !== 'object' ? (value || 'Not set') : value}</span>
  </div>
);

const EditInput: React.FC<{ label: string; name: string; value: any; onChange: any; type?: string, placeholder?: string }> = ({ label, name, value, onChange, type = 'text', placeholder }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700">{label}</label>
        <input type={type} name={name} value={value} onChange={onChange} placeholder={placeholder} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-orange-500 focus:border-orange-500" />
    </div>
);

const EditSelect: React.FC<{ label: string; name: string; value: any; onChange: any; children: React.ReactNode }> = ({ label, name, value, onChange, children }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700">{label}</label>
        <select name={name} value={value} onChange={onChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-orange-500 focus:border-orange-500 sm:text-sm rounded-md bg-white">
            {children}
        </select>
    </div>
);

export default ProfileScreen;
