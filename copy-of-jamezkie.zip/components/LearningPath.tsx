import React, { useState } from 'react';
import { LearningPath, Module, Lesson } from '../types';
import { ChevronDownIcon } from './icons/ChevronDownIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';

interface LearningPathComponentProps {
  path: LearningPath;
  completedLessons: Set<string>;
  onToggleLesson: (lessonTitle: string) => void;
}

const LessonCard: React.FC<{ lesson: Lesson, isCompleted: boolean, onToggle: () => void }> = ({ lesson, isCompleted, onToggle }) => (
    <div className={`bg-white rounded-lg overflow-hidden border transition-all duration-300 shadow-sm hover:-translate-y-1 relative ${isCompleted ? 'border-green-400 bg-green-50/50' : 'border-gray-200 hover:border-blue-500/50 hover:shadow-blue-500/10'}`}>
        {isCompleted && (
            <div className="absolute top-3 right-3 text-green-500">
                <CheckCircleIcon className="w-6 h-6" />
            </div>
        )}
        <img
            className="w-full h-32 object-cover"
            src={`https://picsum.photos/seed/${encodeURIComponent(lesson.title)}/600/300`}
            alt={`Visual representation for ${lesson.title}`}
            loading="lazy"
        />
        <div className="p-4">
            <h4 className={`font-semibold ${isCompleted ? 'text-green-800' : 'text-blue-600'}`}>{lesson.title}</h4>
            <p className={`text-gray-600 mt-2 text-sm ${isCompleted ? 'opacity-75' : ''}`}>{lesson.description}</p>
        </div>
        <div className="p-4 pt-0">
            <button
                onClick={onToggle}
                className={`w-full text-sm font-bold py-2 px-4 rounded-lg transition-colors ${isCompleted ? 'bg-green-100 text-green-800 hover:bg-green-200' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
            >
                {isCompleted ? 'Mark as Incomplete' : 'Mark as Complete'}
            </button>
        </div>
    </div>
);

const ModuleComponent: React.FC<{ module: Module; initialOpen?: boolean; completedLessons: Set<string>; onToggleLesson: (lessonTitle: string) => void; }> = ({ module, initialOpen = false, completedLessons, onToggleLesson }) => {
  const [isOpen, setIsOpen] = useState(initialOpen);

  return (
    <div className="border border-gray-200 rounded-lg mb-4 bg-white/50 transition-all">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-5 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-lg"
        aria-expanded={isOpen}
      >
        <div className="flex-1 pr-4">
          <h3 className="text-xl font-bold text-gray-900">{module.title}</h3>
          <p className="text-gray-500 mt-1 text-sm">{module.description}</p>
        </div>
        <ChevronDownIcon
          className={`w-6 h-6 text-gray-500 transform transition-transform duration-300 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${
          isOpen ? 'max-h-[2000px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="p-5 border-t border-gray-200">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {module.lessons.map((lesson, index) => (
              <div key={index} className="animate-fade-in-zoom" style={{ animationDelay: `${index * 100}ms` }}>
                <LessonCard 
                  lesson={lesson}
                  isCompleted={completedLessons.has(lesson.title)}
                  onToggle={() => onToggleLesson(lesson.title)}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const LearningPathComponent: React.FC<LearningPathComponentProps> = ({ path, completedLessons, onToggleLesson }) => {
  return (
    <div className="mt-8 animate-fade-in">
      <h2 className="text-3xl font-bold mb-6 text-center text-gray-900">Your AI-Generated Learning Path</h2>
      <div>
        {path.modules.map((module, index) => (
          <ModuleComponent 
            key={index} 
            module={module} 
            initialOpen={index === 0} 
            completedLessons={completedLessons}
            onToggleLesson={onToggleLesson}
          />
        ))}
      </div>
    </div>
  );
};

export default LearningPathComponent;