import React, { useState, useRef } from 'react';
import { User, EnrollmentDetails } from '../types';
import { ArrowLeftIcon } from './icons/ArrowLeftIcon';

interface EnrollmentScreenProps {
    user: User;
    onBack: () => void;
    onEnrollmentComplete: () => void;
}

const EnrollmentScreen: React.FC<EnrollmentScreenProps> = ({ user, onBack, onEnrollmentComplete }) => {
    const [formData, setFormData] = useState({
        fullName: user.fullName || '',
        gCashNumber: '',
        referenceNumber: '',
        paymentProof: ''
    });
    const [error, setError] = useState('');
    const [fileName, setFileName] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({...prev, [name]: value}));
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 2 * 1024 * 1024) { // 2MB limit
                setError('File is too large. Please upload an image under 2MB.');
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData(prev => ({...prev, paymentProof: reader.result as string}));
                setFileName(file.name);
                setError('');
            };
            reader.onerror = () => {
                setError('Failed to read file.');
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.fullName || !formData.gCashNumber || !formData.referenceNumber || !formData.paymentProof) {
            setError('Please fill out all fields and upload proof of payment.');
            return;
        }

        const enrollmentDetails: EnrollmentDetails = {
            ...formData,
            gmail: user.email,
            submissionDate: new Date().toISOString(),
        };

        const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
        const userIndex = users.findIndex(u => u.email === user.email);

        if (userIndex !== -1) {
            users[userIndex].status = 'pending';
            users[userIndex].enrollmentDetails = enrollmentDetails;
            localStorage.setItem('users', JSON.stringify(users));
            onEnrollmentComplete();
        } else {
            setError('Could not find user. Please log out and try again.');
        }
    };

    return (
        <div className="max-w-xl mx-auto p-4 font-sans animate-fade-in">
            <div className="flex items-center mb-6">
                <button
                onClick={onBack}
                className="flex items-center gap-2 text-blue-600 font-semibold transition-colors hover:text-blue-800 focus:outline-none"
                >
                <ArrowLeftIcon className="w-5 h-5" />
                Back to Courses
                </button>
            </div>
            
            <div className="bg-white p-6 rounded-2xl shadow-sm">
                <div className="text-center mb-6">
                    <h1 className="text-3xl font-bold text-gray-900">Unlock All Courses</h1>
                    <p className="text-gray-600 mt-2">Get lifetime access to everything for a one-time payment of <strong>₱199</strong>.</p>
                </div>

                <div className="bg-amber-50 border-l-4 border-amber-500 text-amber-800 p-4 rounded-r-lg mb-6">
                    <h4 className="font-bold mb-2">Important Instructions</h4>
                    <ol className="list-decimal list-inside space-y-1 text-sm">
                        <li>Make sure you are logged into the correct account.</li>
                        <li>Send <strong>₱199</strong> via GCash to <strong>09164629678</strong>.</li>
                        <li>Take a screenshot of your successful payment receipt.</li>
                        <li>Fill out the form below and upload the screenshot.</li>
                        <li>Wait for approval from our team (typically 1-5 hours).</li>
                    </ol>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">Full Name</label>
                        <input type="text" name="fullName" id="fullName" value={formData.fullName} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500" />
                    </div>
                    <div>
                        <label htmlFor="gCashNumber" className="block text-sm font-medium text-gray-700">Your GCash Number</label>
                        <input type="text" name="gCashNumber" id="gCashNumber" value={formData.gCashNumber} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500" />
                    </div>
                     <div>
                        <label htmlFor="referenceNumber" className="block text-sm font-medium text-gray-700">GCash Reference Number</label>
                        <input type="text" name="referenceNumber" id="referenceNumber" value={formData.referenceNumber} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Upload Proof of Payment</label>
                        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                            <div className="space-y-1 text-center">
                                <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                                <div className="flex text-sm text-gray-600">
                                    <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-orange-600 hover:text-orange-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-orange-500">
                                        <span>Upload a file</span>
                                        <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/png, image/jpeg, image/jpg" ref={fileInputRef} />
                                    </label>
                                    <p className="pl-1">or drag and drop</p>
                                </div>
                                <p className="text-xs text-gray-500">PNG, JPG up to 2MB</p>
                            </div>
                        </div>
                        {fileName && <p className="text-sm text-green-600 mt-2 text-center">File selected: {fileName}</p>}
                    </div>
                    
                    {error && <p className="text-red-600 text-sm text-center font-semibold">{error}</p>}

                    <button type="submit" className="w-full bg-orange-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-orange-600 transition-colors shadow-lg transform hover:scale-105">
                        Submit Enrollment
                    </button>
                </form>
            </div>
        </div>
    );
};

export default EnrollmentScreen;
