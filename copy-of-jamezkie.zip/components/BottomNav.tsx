import React from 'react';
import { HomeIcon } from './icons/HomeIcon';
import { GraduationCapIcon } from './icons/GraduationCapIcon';
import { DocumentTextIcon } from './icons/DocumentTextIcon';
import { UserCircleIcon } from './icons/UserCircleIcon';

interface BottomNavProps {
  activeView: 'main' | 'profile';
  onNavClick: (view: 'home' | 'my-course' | 'blog' | 'profile') => void;
}

const NavItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick: () => void; }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className="flex flex-col items-center justify-center w-full h-full text-gray-500 hover:text-orange-500 transition-colors focus:outline-none"
  >
    <div className={`w-8 h-8 flex items-center justify-center ${active ? 'text-orange-500' : ''}`}>
      <div className={active ? 'animate-bounce-in' : ''}>
        {icon}
      </div>
    </div>
    <span className={`text-xs font-semibold ${active ? 'text-orange-500' : ''}`}>{label}</span>
  </button>
);

const BottomNav: React.FC<BottomNavProps> = ({ activeView, onNavClick }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 h-20 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
      <div className="container mx-auto h-full grid grid-cols-4">
        <NavItem 
            icon={<HomeIcon className="w-6 h-6" />} 
            label="Home" 
            active={activeView === 'main'}
            onClick={() => onNavClick('home')}
        />
        <NavItem 
            icon={<GraduationCapIcon className="w-6 h-6" />} 
            label="My Course" 
            onClick={() => onNavClick('my-course')}
        />
        <NavItem 
            icon={<DocumentTextIcon className="w-6 h-6" />} 
            label="Blog" 
            onClick={() => onNavClick('blog')}
        />
        <NavItem 
            icon={<UserCircleIcon className="w-6 h-6" />} 
            label="Profile" 
            active={activeView === 'profile'}
            onClick={() => onNavClick('profile')}
        />
      </div>
    </div>
  );
};

export default BottomNav;