import React from 'react';
import { User } from '../types';

interface HeaderProps {
  currentUser: User | null;
}

const Header: React.FC<HeaderProps> = ({ currentUser }) => {
  const userName = currentUser?.fullName || currentUser?.name || 'Guest';
  const avatarSrc = currentUser?.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&background=fdba74&color=fff&bold=true`;

  return (
    <header className="px-4 pt-8 pb-4">
      <div className="container mx-auto flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Hi, {userName === 'Guest' ? 'There' : userName}</h1>
          <p className="text-gray-500">Find your lessons today!</p>
        </div>
        {currentUser ? (
             <img src={avatarSrc} alt={userName} className="w-12 h-12 rounded-full object-cover shadow-md" />
        ) : (
            <div className="w-12 h-12 bg-gray-200 rounded-full"></div> // Placeholder for logged-out user
        )}
      </div>
    </header>
  );
};

export default Header;