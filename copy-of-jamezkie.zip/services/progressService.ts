import { LearningPath } from '../types';

const PROGRESS_STORAGE_KEY = 'courseProgressData';

interface StoredCourseData {
  learningPath: LearningPath;
  completedLessons: string[];
}

// Get all progress data from localStorage
const getAllProgressData = (): Record<string, StoredCourseData> => {
  const data = localStorage.getItem(PROGRESS_STORAGE_KEY);
  return data ? JSON.parse(data) : {};
};

// Save all progress data to localStorage
const saveAllProgressData = (data: Record<string, StoredCourseData>) => {
  localStorage.setItem(PROGRESS_STORAGE_KEY, JSON.stringify(data));
};

// Get data for a specific course
export const getStoredCourseData = (courseId: string): StoredCourseData | null => {
  const allData = getAllProgressData();
  return allData[courseId] || null;
};

// Store a newly generated learning path
export const storeLearningPath = (courseId: string, learningPath: LearningPath) => {
  const allData = getAllProgressData();
  allData[courseId] = {
    learningPath,
    completedLessons: allData[courseId]?.completedLessons || [],
  };
  saveAllProgressData(allData);
};

// Toggle a lesson's completion status
export const toggleLessonComplete = (courseId: string, lessonTitle: string) => {
  const allData = getAllProgressData();
  const courseData = allData[courseId];

  if (!courseData) return;

  const completed = new Set(courseData.completedLessons);
  if (completed.has(lessonTitle)) {
    completed.delete(lessonTitle);
  } else {
    completed.add(lessonTitle);
  }
  
  courseData.completedLessons = Array.from(completed);
  saveAllProgressData(allData);
};

// Calculate progress percentage for a course
export const getCourseProgressPercentage = (courseId: string): number => {
    const courseData = getStoredCourseData(courseId);
    if (!courseData || !courseData.learningPath) return 0;

    const { learningPath, completedLessons } = courseData;
    const totalLessons = learningPath.modules.reduce((acc, module) => acc + module.lessons.length, 0);
    
    if (totalLessons === 0) return 0;

    const completedCount = completedLessons.length;
    return Math.round((completedCount / totalLessons) * 100);
}
