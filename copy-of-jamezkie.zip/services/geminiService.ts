
import { GoogleGenAI, Type } from "@google/genai";
import { LearningPath } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const learningPathSchema = {
  type: Type.OBJECT,
  properties: {
    modules: {
      type: Type.ARRAY,
      description: "A list of modules that make up the course.",
      items: {
        type: Type.OBJECT,
        properties: {
          title: {
            type: Type.STRING,
            description: "The title of the module."
          },
          description: {
            type: Type.STRING,
            description: "A brief one-sentence overview of what the module covers."
          },
          lessons: {
            type: Type.ARRAY,
            description: "A list of lessons within this module.",
            items: {
              type: Type.OBJECT,
              properties: {
                title: {
                  type: Type.STRING,
                  description: "The title of the lesson."
                },
                description: {
                  type: Type.STRING,
                  description: "A detailed, one-paragraph explanation of the lesson's content and objectives."
                }
              },
              required: ["title", "description"]
            }
          }
        },
        required: ["title", "description", "lessons"]
      }
    }
  },
  required: ["modules"]
};

export const generateLearningPath = async (courseTitle: string): Promise<LearningPath> => {
  const prompt = `Generate a comprehensive, structured learning path for a course titled "${courseTitle}". The path should be broken down into logical modules, and each module should contain several detailed lessons. The output should be a curriculum suitable for a beginner.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: learningPathSchema,
        temperature: 0.7,
      },
    });

    const jsonText = response.text.trim();
    const parsedData = JSON.parse(jsonText);
    
    // Basic validation to ensure the structure matches LearningPath
    if (parsedData && Array.isArray(parsedData.modules)) {
      return parsedData as LearningPath;
    } else {
      throw new Error("Invalid data structure received from API.");
    }

  } catch (error) {
    console.error("Error generating learning path:", error);
    throw new Error("Failed to generate a learning path. The AI may be experiencing high traffic. Please try again later.");
  }
};
