import React, { useState, useEffect } from 'react';
import HomeScreen from './components/HomeScreen';
import CourseDetail from './components/CourseDetail';
import BottomNav from './components/BottomNav';
import AuthModal from './components/AuthModal';
import SetupProfileScreen from './components/SetupProfileScreen';
import ProfileScreen from './components/ProfileScreen';
import { Course, User } from './types';
import SplashScreen from './components/SplashScreen';
import WelcomeScreen from './components/WelcomeScreen';
import { CURRENT_APP_VERSION } from './updateInfo';
import UpdateNotification from './components/UpdateNotification';
import AdminPanel from './components/AdminPanel';

const App: React.FC = () => {
  const [isAppLoading, setIsAppLoading] = useState(true);
  const [welcomedUser, setWelcomedUser] = useState<User | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [isAuthModalOpen, setAuthModalOpen] = useState(false);
  const [activeView, setActiveView] = useState<'main' | 'profile'>('main');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [showUpdateModal, setShowUpdateModal] = useState(false);

  useEffect(() => {
    const splashTimer = setTimeout(() => {
      setIsAppLoading(false);
    }, 3000);

    const lastSeenVersion = localStorage.getItem('lastSeenVersion');
    if (lastSeenVersion !== CURRENT_APP_VERSION) {
        setShowUpdateModal(true);
    }

    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
      const fullUser = users.find(u => u.email === JSON.parse(storedUser).email);
      if (fullUser) {
        setCurrentUser(fullUser);
      }
    }
    
    // Check for admin session
    const adminSession = sessionStorage.getItem('isAdminLoggedIn');
    if (adminSession === 'true') {
        setIsAdminLoggedIn(true);
    }

    return () => clearTimeout(splashTimer);
  }, []);

  const handleCloseUpdateModal = () => {
    localStorage.setItem('lastSeenVersion', CURRENT_APP_VERSION);
    setShowUpdateModal(false);
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('currentUser', JSON.stringify(user));
    setAuthModalOpen(false);
    setWelcomedUser(user);
  };

  const handleAdminLogin = () => {
    setIsAdminLoggedIn(true);
    sessionStorage.setItem('isAdminLoggedIn', 'true');
    setAuthModalOpen(false);
  };

  const onWelcomeFinished = () => {
    if (welcomedUser && !welcomedUser.profileComplete) {
      setActiveView('profile');
    }
    setWelcomedUser(null);
  };

  const handleLogout = () => {
    if (isAdminLoggedIn) {
        setIsAdminLoggedIn(false);
        sessionStorage.removeItem('isAdminLoggedIn');
    } else {
        setCurrentUser(null);
        localStorage.removeItem('currentUser');
        setActiveView('main');
        setSelectedCourse(null);
    }
  };
  
  const handleProfileUpdate = (updatedData: Partial<User>) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, ...updatedData, profileComplete: true };
    setCurrentUser(updatedUser);

    const users: User[] = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex(u => u.email === currentUser.email);
    if (userIndex !== -1) {
      users[userIndex] = updatedUser;
      localStorage.setItem('users', JSON.stringify(users));
      localStorage.setItem('currentUser', JSON.stringify(updatedUser));
    }
  };

  const handleNavClick = (view: 'home' | 'profile' | 'my-course' | 'blog') => {
     if (view === 'home') {
      setActiveView('main');
      setSelectedCourse(null);
    } else if (view === 'profile') {
      if (!currentUser) {
        setAuthModalOpen(true);
      } else {
        setActiveView('profile');
      }
    } else {
      alert(`The "${view}" page is for demonstration purposes and is not implemented yet.`);
    }
  };
  
  const handleSelectCourse = (course: Course) => {
    if (!currentUser) {
        setAuthModalOpen(true);
        return;
    }
    setSelectedCourse(course);
  };

  const handleBackToCourses = () => {
    setSelectedCourse(null);
  };

  const renderContent = () => {
    if (isAdminLoggedIn) {
        return <AdminPanel onLogout={handleLogout} />;
    }
      
    if (activeView === 'profile' && currentUser) {
      if (!currentUser.profileComplete) {
        return <SetupProfileScreen onProfileComplete={handleProfileUpdate} />;
      }
      return <ProfileScreen user={currentUser} onLogout={handleLogout} onUpdateProfile={handleProfileUpdate} />;
    }

    if (selectedCourse) {
      return <CourseDetail course={selectedCourse} onBack={handleBackToCourses} />;
    }

    return <HomeScreen onSelectCourse={handleSelectCourse} currentUser={currentUser} />;
  };

  if (isAppLoading) {
    return <SplashScreen />;
  }

  return (
    <div className="bg-gray-50 min-h-screen font-sans">
      {showUpdateModal && <UpdateNotification onClose={handleCloseUpdateModal} />}
      {welcomedUser && (
        <WelcomeScreen onFinished={onWelcomeFinished} userName={welcomedUser.fullName || welcomedUser.name} />
      )}
      <div className={`${isAdminLoggedIn ? '' : 'pb-24'}`}>
        {renderContent()}
      </div>
      {!isAdminLoggedIn && <BottomNav onNavClick={handleNavClick} activeView={activeView} />}
      {isAuthModalOpen && (
        <AuthModal 
          onClose={() => setAuthModalOpen(false)}
          onLoginSuccess={handleLogin}
          onSignupSuccess={handleLogin}
          onAdminLogin={handleAdminLogin}
        />
      )}
    </div>
  );
};

export default App;
