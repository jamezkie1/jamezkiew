export const CURRENT_APP_VERSION = '1.1.0';

export const CHANGELOG = [
    {
        title: "Profile Editing is Here!",
        description: "You can now edit your profile information, including your name, mobile, age, and role. You can also upload a new profile picture!"
    },
    {
        title: "Password Management",
        description: "Securely change your account password directly from your profile settings."
    },
    {
        title: "Enhanced User Interface",
        description: "We've polished the UI across the app for a smoother and more enjoyable learning experience."
    },
    {
        title: "Improved Performance",
        description: "General optimizations to make the app faster and more responsive."
    }
];
