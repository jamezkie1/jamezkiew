import { Course } from './types';

export const COURSES: Course[] = [
  {
    id: 'react-front-to-back',
    title: 'React Front To back Master React',
    description: 'Master the core concepts of React, including components, state, props, and hooks.',
    imageUrl: 'https://images.unsplash.com/photo-1542314831-068cd1dbb563?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80',
    category: 'Spoken English',
    videos: 75,
    classes: 35,
    duration: '6h 30min',
    rating: 4.9
  },
  {
    id: 'python-for-data-science',
    title: 'Python for Data Science',
    description: 'Learn Python and its powerful libraries like NumPy, Pandas, and Matplotlib for data analysis.',
    imageUrl: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80',
    category: 'Data Science',
    videos: 60,
    classes: 25,
    duration: '8h 30min',
    rating: 4.8
  },
  {
    id: 'ux-design-principles',
    title: 'UX Design Principles',
    description: 'Understand the fundamental principles of User Experience design to create intuitive products.',
    imageUrl: 'https://images.unsplash.com/photo-1587440871875-191322ee64b0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=871&q=80',
    category: 'Design',
    videos: 45,
    classes: 20,
    duration: '5h 00min',
    rating: 4.9
  },
  {
    id: 'advanced-typescript',
    title: 'Advanced TypeScript',
    description: 'Dive deep into generics, decorators, and advanced type-level programming in TypeScript.',
    imageUrl: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80',
    category: 'Web Development',
    videos: 50,
    classes: 30,
    duration: '7h 15min',
    rating: 4.7
  }
];
